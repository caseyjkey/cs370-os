// Watch helpdesk video before asking for help

#include <string.h>
#include <stdlib.h> 
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

#define IMAGE_HEIGHT 76
#define IMAGE_WIDTH 76

//static int findThreeValues(int coded, int &red, int &green, int &blue);

// This function spawns three child processes, one for each color
static int findThreeValues(char coded[], int *red, int *green, int *blue) {
		// Store color byte in decodedValue
		int decodedValue;
		pid_t cpid = fork();
		// If we are in child process, run the Red program with coded as an argument
		if(cpid == 0) {
			execlp("./Red", "Red", coded, NULL); //(char) coded, NULL);	
		}
		// If we are parent, wait for child to finish processing
		else if (cpid > 0) {
			printf("Starter: Forked process with ID %d.\n", cpid);
			printf("Starter: Waiting for process [%d].\n", cpid);
			// We get exit value
			wait(&decodedValue);
			// // Find the value returned from Red
			*red = WEXITSTATUS(decodedValue);
			printf("Starter: Child process %d returned %d.\n", cpid, *red);
		}
		else
			printf("ERROR");
		
		// Repeat above procedure for Green
		cpid = fork();
		if(cpid == 0) {
			execlp("./Green", "Green", coded, NULL);	
		}
		else if (cpid > 0) {
			printf("Starter: Forked process with ID %d.\n", cpid);
			printf("Starter: Waiting for process [%d].\n", cpid);
			wait(&decodedValue);
			*green = WEXITSTATUS(decodedValue);
			printf("Starter: Child process %d returned %d.\n", cpid, *green);
		}
		else
			printf("ERROR");
		

		// Repeat procedure for Blue
		cpid = fork();
		if(cpid == 0) {
			execlp("./Blue", "Blue", coded, NULL);	
		}
		else if (cpid > 0) {
			
			printf("Starter: Forked process with ID %d.\n", cpid);
			printf("Starter: Waiting for process [%d].\n", cpid);
			wait(&decodedValue);
			*blue = WEXITSTATUS(decodedValue);
			printf("Starter: Child process %d returned %d.\n", cpid, *blue);
		}
		else
			printf("ERROR");
	
		return 0;

}


int main(int argc, const char *argv[]) {
	// Check if a filename has been passed as argument
	char filename[50];
	if(argc == 2) {
		strcpy(filename, argv[1]);
	}
	// If not, use default value
	else { 
		strcpy(filename, "coded_image_1.txt");
	}
	
	// Create output filename given the input filename
	char outputFileName[30]= "";
	char extension[12] = "_output.ppm";
	strcpy(outputFileName, filename);
	char* pos = strchr(outputFileName,'.');
	*pos = '\0';
	strcat(outputFileName,extension);
	
	// Open input filename for reading
	FILE *fin = fopen(filename, "r");
	// Loop until there are no more input from the file
	int coded;
	int RED_VALUE[5776], GREEN_VALUE[5776], BLUE_VALUE[5776];
	int i = 0;
	char sNum[20];
	// Store the coded input number into coded
	while(fscanf(fin, "%d", &coded) == 1 && i < 5776) {
		// Convert coded int into a character array
		sprintf(sNum, "%d", coded);
		// Pass coded char[] to find the three color bytes
		// Store decoded color values into corresponding arrays
		findThreeValues(sNum, &RED_VALUE[i], &GREEN_VALUE[i], &BLUE_VALUE[i]);	
		i += 1;
	}
	// Close the output file
	fclose(fin);


	// Output color bytes to ppm file
	// First, open the file for writing as binary with fopen
	FILE *fout = fopen(outputFileName, "wb");
	// Write magic number to first line of file
	fprintf(fout, "P6\n%i %i 255\n", IMAGE_HEIGHT, IMAGE_WIDTH); 
	// Write out all bytes to the file
	for (int i=0; i<IMAGE_HEIGHT*IMAGE_WIDTH; i++){ 
		fputc(RED_VALUE[i], fout); // 0 .. 255 
		fputc(GREEN_VALUE[i], fout); // 0 .. 255 
		fputc(BLUE_VALUE[i], fout); // 0 .. 255 
	} 
	// Close the picture file
	fclose(fout);	
	printf("Starter: %s file written and closed.\n", outputFileName);
	return 0;
}


