1. How many of the least significant bits of the status does WEXITSTATUS return?
-- The low order 8 bits

2. Which header file has to be included to use the WEXITSTATUS?
-- wait.h

3. What is the return value for the fork() in a child process?
-- 0

4. Give a reason for the fork() to fail?
-- There are too many processes running

5. In the program written by you, are we doing a sequential processing or a concurrent processing with respect to the child processes? Sequential processing is when only one of the child processes is running at one time, and concurrent processing is when more than one child process can be running at the same time.  
-- In my program, we are doing sequential processing
